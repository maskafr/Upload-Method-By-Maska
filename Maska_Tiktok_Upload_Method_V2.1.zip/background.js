const MOBILE_UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
const DEFAULT_SETTINGS = {
    sysActive: false,
    playbackActive: true,
    qualityTarget: '1080p',
    fpsTarget: 60,
    blockCompression: true,
    blockTranscode: true,
    forceHighBitrate: true,
    removeWatermark: true,
    preserveHDR: true,
    interceptCount: 0,
    blockCount: 0
};
const UA_RULES = [
    {
        id: 1,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'User-Agent',
                operation: 'set',
                value: MOBILE_UA
            }]
        },
        condition: {
            regexFilter: '.*tiktokcdn.*\\/video\\/.*',
            resourceTypes: ['xmlhttprequest', 'media', 'other', 'sub_frame', 'main_frame', 'script', 'image']
        }
    },
    {
        id: 2,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'User-Agent',
                operation: 'set',
                value: MOBILE_UA
            }]
        },
        condition: {
            regexFilter: '.*tiktokcdn-us.*\\/video\\/.*',
            resourceTypes: ['xmlhttprequest', 'media', 'other', 'sub_frame', 'main_frame', 'script', 'image']
        }
    },
    {
        id: 3,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'User-Agent',
                operation: 'set',
                value: MOBILE_UA
            }]
        },
        condition: {
            urlFilter: '||v16m-default.tiktokcdn.com',
            resourceTypes: ['xmlhttprequest', 'media', 'other', 'sub_frame']
        }
    },
    {
        id: 4,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'User-Agent',
                operation: 'set',
                value: MOBILE_UA
            }]
        },
        condition: {
            urlFilter: '||v19-default.tiktokcdn.com',
            resourceTypes: ['xmlhttprequest', 'media', 'other', 'sub_frame']
        }
    },
    {
        id: 5,
        priority: 1,
        action: {
            type: 'modifyHeaders',
            requestHeaders: [{
                header: 'User-Agent',
                operation: 'set',
                value: MOBILE_UA
            }]
        },
        condition: {
            urlFilter: '||v77-default.tiktokcdn.com',
            resourceTypes: ['xmlhttprequest', 'media', 'other', 'sub_frame']
        }
    }
];
async function injectIntoTab(tabId) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            files: ['playback-content.js']
        });
        return true;
    } catch (e) {
        return false;
    }
}
async function injectAllTikTokTabs() {
    const tabs = await chrome.tabs.query({ url: 'https://www.tiktok.com/*' });
    for (const tab of tabs) {
        await injectIntoTab(tab.id);
    }
}
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(Object.keys(DEFAULT_SETTINGS), (res) => {
        const toSet = {};
        for (const [key, val] of Object.entries(DEFAULT_SETTINGS)) {
            if (res[key] === undefined) toSet[key] = val;
        }
        if (Object.keys(toSet).length > 0) chrome.storage.local.set(toSet);
    });
    updateBadge(false);
    enablePlaybackRules(true);
    injectAllTikTokTabs();
});
function updateBadge(isActive) {
    chrome.action.setBadgeBackgroundColor({ color: isActive ? '#1dffb2' : '#6f7f98' });
    chrome.action.setBadgeText({ text: isActive ? 'ON' : '' });
}
function enablePlaybackRules(enabled) {
    if (enabled) {
        chrome.declarativeNetRequest.updateDynamicRules({
            addRules: UA_RULES,
            removeRuleIds: UA_RULES.map(r => r.id)
        }).catch(e => console.log('Rule error:', e));
    } else {
        chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: UA_RULES.map(r => r.id)
        }).catch(() => {});
    }
}
async function sendToTabWithRetry(tabId, message) {
    try {
        return await chrome.tabs.sendMessage(tabId, message);
    } catch (e) {
        const injected = await injectIntoTab(tabId);
        if (injected) {
            await new Promise(r => setTimeout(r, 200));
            try {
                return await chrome.tabs.sendMessage(tabId, message);
            } catch (e2) {
                return null;
            }
        }
        return null;
    }
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'STATE_CHANGED') {
        updateBadge(msg.enabled);
        chrome.tabs.query({ url: 'https://www.tiktok.com/*' }, (tabs) => {
            tabs.forEach((tab) => {
                chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_STATE', enabled: msg.enabled }).catch(() => {});
            });
        });
    }
    if (msg.type === 'PLAYBACK_CHANGED') {
        enablePlaybackRules(msg.enabled);
    }
    if (msg.type === 'SETTINGS_CHANGED') {
        chrome.tabs.query({ url: 'https://www.tiktok.com/*' }, (tabs) => {
            tabs.forEach((tab) => {
                chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_UPDATE', settings: msg.settings }).catch(() => {});
            });
        });
    }
    if (msg.type === 'INCREMENT_STAT') {
        chrome.storage.local.get([msg.stat], (res) => {
            chrome.storage.local.set({ [msg.stat]: (res[msg.stat] || 0) + 1 });
        });
    }
    if (msg.type === 'LOG_EVENT') {
        chrome.runtime.sendMessage(msg).catch(() => {});
    }
    if (msg.type === 'GET_VIDEO_INFO') {
        chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
            if (tabs[0] && tabs[0].url && tabs[0].url.includes('tiktok.com')) {
                const response = await sendToTabWithRetry(tabs[0].id, { type: 'EXTRACT_VIDEO_INFO' });
                if (response) {
                    sendResponse(response);
                } else {
                    sendResponse({ error: 'Could not connect. Try refreshing the TikTok page.' });
                }
            } else {
                sendResponse({ error: 'No TikTok tab active. Open a TikTok video first.' });
            }
        });
        return true;
    }
    if (msg.type === 'SET_PLAYBACK_RATE') {
        chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
            if (tabs[0] && tabs[0].url && tabs[0].url.includes('tiktok.com')) {
                const response = await sendToTabWithRetry(tabs[0].id, { type: 'SET_PLAYBACK_RATE', rate: msg.rate });
                if (response) {
                    sendResponse(response);
                } else {
                    sendResponse({ error: 'Could not connect. Try refreshing the TikTok page.' });
                }
            } else {
                sendResponse({ error: 'No TikTok tab active' });
            }
        });
        return true;
    }
    if (msg.type === 'GET_SETTINGS') {
        chrome.storage.local.get(null, (res) => { sendResponse(res); });
        return true;
    }
});
chrome.storage.local.get(['sysActive', 'playbackActive'], (res) => {
    updateBadge(!!res.sysActive);
    enablePlaybackRules(res.playbackActive !== false);
});