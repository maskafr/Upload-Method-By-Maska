document.addEventListener('DOMContentLoaded', () => {
    const $ = (id) => document.getElementById(id);
    const masterSwitch = $('masterSwitch');
    const masterLabel = $('masterLabel');
    const statusDot = $('statusDot');
    const qualitySelector = $('qualitySelector');
    const fpsSelector = $('fpsSelector');
    const togglePlayback = $('togglePlayback');
    const toggleCompression = $('toggleCompression');
    const toggleTranscode = $('toggleTranscode');
    const toggleBitrate = $('toggleBitrate');
    const toggleWatermark = $('toggleWatermark');
    const toggleHDR = $('toggleHDR');
    const chipQuality = $('chipQuality');
    const chipFPS = $('chipFPS');
    const chipPlayback = $('chipPlayback');
    const chipCompress = $('chipCompress');
    const chipTranscode = $('chipTranscode');
    const chipBitrate = $('chipBitrate');
    const statIntercepted = $('statIntercepted');
    const statBlocked = $('statBlocked');
    const logBody = $('logBody');
    const logClear = $('logClear');
    const btnVideoInfo = $('btnVideoInfo');
    const videoInfoPanel = $('videoInfoPanel');
    const videoInfoContent = $('videoInfoContent');
    const videoInfoLoading = $('videoInfoLoading');
    const videoInfoError = $('videoInfoError');
    if (!masterSwitch) return;
    const logEntries = [];
    function updateMasterUI(isActive) {
        if (masterSwitch) masterSwitch.checked = isActive;
        if (masterLabel) {
            masterLabel.textContent = isActive ? 'ENABLED' : 'DISABLED';
            masterLabel.classList.toggle('active', isActive);
        }
        if (statusDot) statusDot.classList.toggle('active', isActive);
    }
    function updateChips(s) {
        const q = s.qualityTarget || '1080p';
        if (chipQuality) { chipQuality.textContent = q.toUpperCase(); chipQuality.classList.toggle('active', q !== 'original'); }
        const f = s.fpsTarget;
        if (chipFPS) { chipFPS.textContent = f === 'original' ? 'ORIG FPS' : f + 'FPS'; chipFPS.classList.toggle('active', f !== 'original'); }
        if (chipPlayback) chipPlayback.classList.toggle('active', !!s.playbackActive);
        if (chipCompress) chipCompress.classList.toggle('active', !!s.blockCompression);
        if (chipTranscode) chipTranscode.classList.toggle('active', !!s.blockTranscode);
        if (chipBitrate) chipBitrate.classList.toggle('active', !!s.forceHighBitrate);
    }
    function updateSelectorUI(container, value) {
        if (!container) return;
        container.querySelectorAll('.selector-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.value === String(value));
        });
    }
    function updateStats(ic, bc) {
        if (statIntercepted) statIntercepted.textContent = ic || 0;
        if (statBlocked) statBlocked.textContent = bc || 0;
    }
    chrome.storage.local.get(null, (res) => {
        updateMasterUI(!!res.sysActive);
        const qt = res.qualityTarget || '1080p';
        const ft = res.fpsTarget !== undefined ? res.fpsTarget : 60;
        updateSelectorUI(qualitySelector, qt);
        updateSelectorUI(fpsSelector, ft);
        if (togglePlayback) togglePlayback.checked = res.playbackActive !== false;
        if (toggleCompression) toggleCompression.checked = res.blockCompression !== false;
        if (toggleTranscode) toggleTranscode.checked = res.blockTranscode !== false;
        if (toggleBitrate) toggleBitrate.checked = res.forceHighBitrate !== false;
        if (toggleWatermark) toggleWatermark.checked = res.removeWatermark !== false;
        if (toggleHDR) toggleHDR.checked = res.preserveHDR !== false;
        updateChips({
            qualityTarget: qt, fpsTarget: ft,
            playbackActive: togglePlayback ? togglePlayback.checked : true,
            blockCompression: toggleCompression ? toggleCompression.checked : true,
            blockTranscode: toggleTranscode ? toggleTranscode.checked : true,
            forceHighBitrate: toggleBitrate ? toggleBitrate.checked : true
        });
        updateStats(res.interceptCount, res.blockCount);
    });
    if (masterSwitch) {
        masterSwitch.addEventListener('change', (e) => {
            const isActive = e.target.checked;
            updateMasterUI(isActive);
            chrome.storage.local.set({ sysActive: isActive });
            chrome.runtime.sendMessage({ type: 'STATE_CHANGED', enabled: isActive });
        });
    }
    if (togglePlayback) {
        togglePlayback.addEventListener('change', () => {
            const enabled = togglePlayback.checked;
            chrome.storage.local.set({ playbackActive: enabled });
            chrome.runtime.sendMessage({ type: 'PLAYBACK_CHANGED', enabled });
            if (chipPlayback) chipPlayback.classList.toggle('active', enabled);
        });
    }
    if (qualitySelector) {
        qualitySelector.addEventListener('click', (e) => {
            const btn = e.target.closest('.selector-btn');
            if (!btn) return;
            updateSelectorUI(qualitySelector, btn.dataset.value);
            chrome.storage.local.set({ qualityTarget: btn.dataset.value });
            broadcastSettings();
        });
    }
    if (fpsSelector) {
        fpsSelector.addEventListener('click', (e) => {
            const btn = e.target.closest('.selector-btn');
            if (!btn) return;
            let value = btn.dataset.value;
            if (value !== 'original') value = parseInt(value, 10);
            updateSelectorUI(fpsSelector, value);
            chrome.storage.local.set({ fpsTarget: value });
            broadcastSettings();
        });
    }
    [
        [toggleCompression, 'blockCompression'],
        [toggleTranscode, 'blockTranscode'],
        [toggleBitrate, 'forceHighBitrate'],
        [toggleWatermark, 'removeWatermark'],
        [toggleHDR, 'preserveHDR']
    ].forEach(([el, key]) => {
        if (!el) return;
        el.addEventListener('change', () => {
            chrome.storage.local.set({ [key]: el.checked });
            broadcastSettings();
        });
    });
    function broadcastSettings() {
        chrome.storage.local.get(null, (res) => {
            const settings = {
                qualityTarget: res.qualityTarget || '1080p',
                fpsTarget: res.fpsTarget !== undefined ? res.fpsTarget : 60,
                playbackActive: res.playbackActive !== false,
                blockCompression: res.blockCompression !== false,
                blockTranscode: res.blockTranscode !== false,
                forceHighBitrate: res.forceHighBitrate !== false,
                removeWatermark: res.removeWatermark !== false,
                preserveHDR: res.preserveHDR !== false
            };
            updateChips(settings);
            chrome.runtime.sendMessage({ type: 'SETTINGS_CHANGED', settings });
        });
    }
    if (btnVideoInfo) {
        btnVideoInfo.addEventListener('click', () => {
            if (videoInfoLoading) videoInfoLoading.style.display = 'block';
            if (videoInfoPanel) videoInfoPanel.style.display = 'none';
            if (videoInfoError) videoInfoError.style.display = 'none';
            btnVideoInfo.disabled = true;
            btnVideoInfo.textContent = '⏳ Scanning...';
            chrome.runtime.sendMessage({ type: 'GET_VIDEO_INFO' }, (response) => {
                btnVideoInfo.disabled = false;
                btnVideoInfo.textContent = '⚡ Scan Video';
                if (videoInfoLoading) videoInfoLoading.style.display = 'none';
                if (!response || response.error) {
                    if (videoInfoError) {
                        videoInfoError.textContent = response?.error || 'Failed to get video info';
                        videoInfoError.style.display = 'block';
                    }
                    return;
                }
                displayVideoInfo(response);
            });
        });
    }
    function displayVideoInfo(info) {
        if (!videoInfoContent || !videoInfoPanel) return;
        const lines = [];
        lines.push('<span style="color:#a86eff;font-weight:bold;">Video:</span>  <span style="color:#4ad8ff;">(https://www.tiktok.com/video/' + info.videoId + ')</span>');
        lines.push('<span style="color:#a86eff;">║</span> 🆔 <span style="color:#f0f6ff;">Video ID</span> <span style="color:#4ad8ff;">' + info.videoId + '</span>');
        if (info.creationDate) {
            lines.push('<span style="color:#a86eff;">║</span> 🗓️ <span style="color:#f0f6ff;">Creation date</span> <span style="color:#4ad8ff;">' + info.creationDate + '</span>');
        }
        if (info.shadowBan !== undefined) {
            const banColor = info.shadowBan === 'No' ? '#1dffb2' : '#ff6b6b';
            lines.push('<span style="color:#a86eff;">║</span> 🌑 <span style="color:#f0f6ff;">Shadow ban</span> <span style="color:' + banColor + ';">' + info.shadowBan + '</span>');
        }
        if (info.author) {
            lines.push('<span style="color:#a86eff;">║</span> 👤 <span style="color:#f0f6ff;">Author</span> <span style="color:#4ad8ff;">@' + info.author + '</span>');
        }
        if (info.locationCreated) {
            const flag = getCountryFlag(info.locationCreated);
            lines.push('<span style="color:#a86eff;">║</span> 🌍 <span style="color:#f0f6ff;">Country</span> <span style="color:#4ad8ff;">' + info.locationCreated + ' ' + flag + '</span>');
        }
        if (info.desc) {
            const shortDesc = info.desc.length > 60 ? info.desc.substring(0, 60) + '...' : info.desc;
            lines.push('<span style="color:#a86eff;">║</span> 📝 <span style="color:#f0f6ff;">Description</span> <span style="color:#8ca4c4;">' + escapeHtml(shortDesc) + '</span>');
        }
        if (info.plays !== undefined) {
            lines.push('');
            lines.push('<span style="color:#1dffb2;font-weight:bold;">📊 Stats</span>');
            lines.push('<span style="color:#a86eff;">║</span> ▶️ <span style="color:#f0f6ff;">Plays</span> <span style="color:#4ad8ff;">' + formatNumber(info.plays) + '</span>');
            if (info.likes !== undefined) lines.push('<span style="color:#a86eff;">║</span> ❤️ <span style="color:#f0f6ff;">Likes</span> <span style="color:#4ad8ff;">' + formatNumber(info.likes) + '</span>');
            if (info.comments !== undefined) lines.push('<span style="color:#a86eff;">║</span> 💬 <span style="color:#f0f6ff;">Comments</span> <span style="color:#4ad8ff;">' + formatNumber(info.comments) + '</span>');
            if (info.shares !== undefined) lines.push('<span style="color:#a86eff;">║</span> 🔗 <span style="color:#f0f6ff;">Shares</span> <span style="color:#4ad8ff;">' + formatNumber(info.shares) + '</span>');
        }
        lines.push('');
        lines.push('<span style="color:#4ad8ff;font-weight:bold;">🌐 In browser</span>');
        if (info.currentSrc) {
            const shortUrl = info.currentSrc.length > 50 ? info.currentSrc.substring(0, 50) + '...' : info.currentSrc;
            lines.push('<span style="color:#4ad8ff;font-size:8px;">(' + escapeHtml(shortUrl) + ')</span>');
        }
        const quality = info.quality || (info.playerWidth ? (Math.min(info.playerWidth, info.playerHeight || info.playerWidth) >= 1080 ? '1080p' : '720p') : '720p');
        const width = info.playerWidth || info.width || '?';
        const height = info.playerHeight || info.height || '?';
        const fps = info.fps || '?';
        const duration = info.duration || '?';
        const bitrateMbps = info.bitrate ? (info.bitrate / 1000000).toFixed(2) : '?';
        const format = info.format || 'mp4';
        const codec = info.codec || 'h264';
        const sizeMB = info.size ? (info.size / 1048576).toFixed(2) : '?';
        lines.push('<span style="color:#6a7dff;">┏</span> <span style="color:#f0f6ff;">Quality</span> <span style="color:#4ad8ff;">' + quality + '</span>');
        lines.push('<span style="color:#6a7dff;">┠</span> <span style="color:#f0f6ff;">FPS</span> <span style="color:#4ad8ff;">' + fps + 'fps</span>');
        lines.push('<span style="color:#6a7dff;">┠</span> <span style="color:#f0f6ff;">Resolution</span> <span style="color:#4ad8ff;">' + width + 'x' + height + '</span>');
        lines.push('<span style="color:#6a7dff;">┠</span> <span style="color:#f0f6ff;">Duration</span> <span style="color:#4ad8ff;">' + duration + 's</span>');
        lines.push('<span style="color:#6a7dff;">┠</span> <span style="color:#f0f6ff;">Bitrate</span> <span style="color:#4ad8ff;">' + bitrateMbps + ' Mbps</span>');
        lines.push('<span style="color:#6a7dff;">┠</span> <span style="color:#f0f6ff;">Format</span> <span style="color:#4ad8ff;">' + format + '</span>');
        lines.push('<span style="color:#6a7dff;">┠</span> <span style="color:#f0f6ff;">Codec</span> <span style="color:#4ad8ff;">' + codec + '</span>');
        lines.push('<span style="color:#6a7dff;">┗</span> <span style="color:#f0f6ff;">Size</span> <span style="color:#4ad8ff;">' + sizeMB + ' MB</span>');
        setSafeHTML(videoInfoContent, lines.join('\n'));
        videoInfoPanel.style.display = 'block';
    }
    function formatNumber(n) {
        if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
        if (n >= 1000) return (n / 1000).toFixed(1) + 'K';
        return String(n);
    }
    function escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    function setSafeHTML(element, html) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        element.replaceChildren(...doc.body.childNodes);
    }
    function getCountryFlag(country) {
        const flags = {
            'Canada': '🇨🇦', 'United States': '🇺🇸', 'USA': '🇺🇸', 'US': '🇺🇸',
            'United Kingdom': '🇬🇧', 'UK': '🇬🇧', 'France': '🇫🇷', 'FR': '🇫🇷',
            'Germany': '🇩🇪', 'DE': '🇩🇪', 'Japan': '🇯🇵', 'JP': '🇯🇵',
            'Brazil': '🇧🇷', 'BR': '🇧🇷', 'Australia': '🇦🇺', 'AU': '🇦🇺',
            'India': '🇮🇳', 'IN': '🇮🇳', 'Mexico': '🇲🇽', 'MX': '🇲🇽',
            'Spain': '🇪🇸', 'ES': '🇪🇸', 'Italy': '🇮🇹', 'IT': '🇮🇹',
            'South Korea': '🇰🇷', 'KR': '🇰🇷', 'Russia': '🇷🇺', 'RU': '🇷🇺',
            'China': '🇨🇳', 'CN': '🇨🇳', 'Indonesia': '🇮🇩', 'ID': '🇮🇩',
            'Turkey': '🇹🇷', 'TR': '🇹🇷', 'Netherlands': '🇳🇱', 'NL': '🇳🇱',
            'Sweden': '🇸🇪', 'SE': '🇸🇪', 'Norway': '🇳🇴', 'NO': '🇳🇴',
            'Portugal': '🇵🇹', 'PT': '🇵🇹', 'Poland': '🇵🇱', 'PL': '🇵🇱',
            'Argentina': '🇦🇷', 'AR': '🇦🇷', 'Colombia': '🇨🇴', 'CO': '🇨🇴',
            'Thailand': '🇹🇭', 'TH': '🇹🇭', 'Vietnam': '🇻🇳', 'VN': '🇻🇳',
            'Philippines': '🇵🇭', 'PH': '🇵🇭', 'Malaysia': '🇲🇾', 'MY': '🇲🇾',
            'Egypt': '🇪🇬', 'EG': '🇪🇬', 'Nigeria': '🇳🇬', 'NG': '🇳🇬',
            'South Africa': '🇿🇦', 'ZA': '🇿🇦', 'Saudi Arabia': '🇸🇦', 'SA': '🇸🇦'
        };
        return flags[country] || '🌍';
    }
    function addLogEntry(data) {
        if (!logBody) return;
        const entry = document.createElement('div');
        entry.className = 'log-entry ' + (data.type || '').toLowerCase().replace('_', '');
        const t = new Date(data.timestamp || Date.now());
        const ts = t.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
        setSafeHTML(entry, '<span class="log-time">' + escapeHtml(ts) + '</span><span class="log-type">[' + escapeHtml(data.type || '') + ']</span> ' + escapeHtml(data.detail || ''));
        const empty = logBody.querySelector('.log-empty');
        if (empty) empty.remove();
        logBody.appendChild(entry);
        logBody.scrollTop = logBody.scrollHeight;
        logEntries.push(data);
        if (logEntries.length > 100) { logEntries.shift(); if (logBody.firstChild) logBody.removeChild(logBody.firstChild); }
    }
    chrome.runtime.onMessage.addListener((msg) => {
        if (msg.type === 'LOG_EVENT' && msg.data) {
            addLogEntry(msg.data);
            chrome.storage.local.get(['interceptCount', 'blockCount'], (res) => { updateStats(res.interceptCount, res.blockCount); });
        }
    });
    if (logClear) {
        logClear.addEventListener('click', () => {
            logEntries.length = 0;
            if (logBody) {
                const empty = document.createElement('div');
                empty.className = 'log-empty';
                empty.textContent = 'Log cleared';
                logBody.replaceChildren(empty);
            }
            chrome.storage.local.set({ interceptCount: 0, blockCount: 0 });
            updateStats(0, 0);
        });
    }
    const speedSelector = $('speedSelector');
    const btnFixSlowMo = $('btnFixSlowMo');
    const btnResetSpeed = $('btnResetSpeed');
    const speedStatus = $('speedStatus');
    let selectedSpeed = 2;
    if (speedSelector) {
        speedSelector.addEventListener('click', (e) => {
            const btn = e.target.closest('.selector-btn');
            if (!btn) return;
            selectedSpeed = parseFloat(btn.dataset.value);
            speedSelector.querySelectorAll('.selector-btn').forEach(b => {
                b.classList.toggle('active', b.dataset.value === btn.dataset.value);
            });
        });
    }
    function sendSpeedCommand(rate) {
        chrome.runtime.sendMessage({ type: 'SET_PLAYBACK_RATE', rate: rate }, (response) => {
            if (speedStatus) {
                if (chrome.runtime.lastError || !response) {
                    speedStatus.style.color = '#ff6b6b';
                    speedStatus.textContent = '❌ No TikTok tab found';
                } else if (response.error) {
                    speedStatus.style.color = '#ff6b6b';
                    speedStatus.textContent = '❌ ' + response.error;
                } else {
                    speedStatus.style.color = '#1dffb2';
                    speedStatus.textContent = '✅ ' + response.message;
                }
                speedStatus.style.display = 'block';
                setTimeout(() => { speedStatus.style.display = 'none'; }, 3000);
            }
        });
    }
    if (btnFixSlowMo) {
        btnFixSlowMo.addEventListener('click', () => sendSpeedCommand(selectedSpeed));
    }
    if (btnResetSpeed) {
        btnResetSpeed.addEventListener('click', () => sendSpeedCommand(1.0));
    }
    setInterval(() => {
        chrome.storage.local.get(['interceptCount', 'blockCount'], (res) => { updateStats(res.interceptCount, res.blockCount); });
    }, 2000);
});