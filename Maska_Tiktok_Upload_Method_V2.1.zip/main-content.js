function showToast(isActive, settings) {
    const existing = document.getElementById('maska-v2-toast');
    if (existing) existing.remove();
    if (!isActive) return;
    const toast = document.createElement('div');
    toast.id = 'maska-v2-toast';
    const qualityLabel = (settings?.qualityTarget || '1080p').toUpperCase();
    const fpsLabel = settings?.fpsTarget || 60;
    const htmlStr = `
        <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:10px;height:10px;border-radius:50%;background:#1dffb2;box-shadow:0 0 8px #1dffb2;"></div>
            <span style="font-weight:900;letter-spacing:2px;">✧ MASKA V2 ACTIVE ✧</span>
        </div>
        <div style="display:flex;gap:8px;margin-top:8px;">
            <span style="background:rgba(74,216,255,0.15);border:1px solid rgba(74,216,255,0.3);padding:3px 8px;border-radius:6px;font-size:10px;letter-spacing:1px;">${qualityLabel}</span>
            <span style="background:rgba(106,125,255,0.15);border:1px solid rgba(106,125,255,0.3);padding:3px 8px;border-radius:6px;font-size:10px;letter-spacing:1px;">${fpsLabel}FPS</span>
            <span style="background:rgba(29,255,178,0.15);border:1px solid rgba(29,255,178,0.3);padding:3px 8px;border-radius:6px;font-size:10px;letter-spacing:1px;">NO COMPRESS</span>
        </div>
    `;
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlStr, 'text/html');
    toast.append(...doc.body.childNodes);
    Object.assign(toast.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        background: 'rgba(10, 15, 30, 0.92)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        color: '#00e5ff',
        border: '1px solid rgba(0, 229, 255, 0.4)',
        boxShadow: '0 0 20px rgba(0, 229, 255, 0.25), 0 8px 32px rgba(0,0,0,0.5)',
        padding: '14px 20px',
        borderRadius: '14px',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        fontSize: '12px',
        fontWeight: '700',
        letterSpacing: '1px',
        zIndex: '2147483647',
        pointerEvents: 'none',
        opacity: '0',
        transform: 'translateY(-15px) scale(0.95)',
        transition: 'opacity 0.5s cubic-bezier(0.16,1,0.3,1), transform 0.5s cubic-bezier(0.16,1,0.3,1)'
    });
    document.body.appendChild(toast);
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0) scale(1)';
    });
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-15px) scale(0.95)';
        setTimeout(() => toast.remove(), 500);
    }, 4000);
}
document.addEventListener('MaskaLogEvent', (e) => {
    try {
        chrome.runtime.sendMessage({
            type: 'LOG_EVENT',
            data: e.detail
        }).catch(() => {});
    } catch (err) {}
});
document.addEventListener('MaskaStatEvent', (e) => {
    try {
        const stat = e.detail === 'intercept' ? 'interceptCount' : 'blockCount';
        chrome.runtime.sendMessage({
            type: 'INCREMENT_STAT',
            stat
        }).catch(() => {});
    } catch (err) {}
});
function init() {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('app-utils.js');
    s.onload = function () {
        this.remove();
        chrome.storage.local.get(null, (res) => {
            const isActive = !!res.sysActive;
            const settings = {
                qualityTarget: res.qualityTarget || '1080p',
                fpsTarget: res.fpsTarget || 60,
                blockCompression: res.blockCompression !== false,
                blockTranscode: res.blockTranscode !== false,
                forceHighBitrate: res.forceHighBitrate !== false,
                removeWatermark: res.removeWatermark !== false,
                preserveHDR: res.preserveHDR !== false
            };
            document.dispatchEvent(new CustomEvent('MaskaStateUpdate', {
                detail: { active: isActive }
            }));
            document.dispatchEvent(new CustomEvent('MaskaSettingsUpdate', {
                detail: settings
            }));
            if (isActive) showToast(true, settings);
        });
    };
    (document.head || document.documentElement).appendChild(s);
}
init();
chrome.runtime.onMessage.addListener((req, sender, sendResp) => {
    if (req.type === 'TOGGLE_STATE') {
        document.dispatchEvent(new CustomEvent('MaskaStateUpdate', {
            detail: { active: req.enabled }
        }));
        chrome.storage.local.get(null, (res) => {
            showToast(req.enabled, res);
        });
    }
    if (req.type === 'SETTINGS_UPDATE') {
        document.dispatchEvent(new CustomEvent('MaskaSettingsUpdate', {
            detail: req.settings
        }));
    }
});