(function() {
    if (window.__maska_playback_active) return;
    window.__maska_playback_active = true;
    const mobileUA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1';
    try {
        Object.defineProperty(navigator, 'userAgent', {
            get: function() { return mobileUA; },
            configurable: true
        });
    } catch(e) {}
    try {
        Object.defineProperty(navigator, 'platform', {
            get: function() { return 'iPhone'; },
            configurable: true
        });
    } catch(e) {}
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((m) => {
            m.addedNodes.forEach((node) => {
                if (node.nodeName === 'VIDEO') enhanceVideo(node);
                if (node.querySelectorAll) node.querySelectorAll('video').forEach(enhanceVideo);
            });
        });
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    function enhanceVideo(v) {
        v.setAttribute('playsinline', '');
        if (v.style.maxHeight) v.style.maxHeight = '';
    }
    document.querySelectorAll('video').forEach(enhanceVideo);
})();