(function () {
    if (window.__maska_v2_active) return;
    window.__maska_v2_active = true;
    const sysState = {
        active: false,
        qualityTarget: '1080p',
        fpsTarget: 60,
        blockCompression: true,
        blockTranscode: true,
        forceHighBitrate: true,
        removeWatermark: true,
        preserveHDR: true
    };
    document.addEventListener('MaskaStateUpdate', (e) => {
        sysState.active = e.detail.active;
    });
    document.addEventListener('MaskaSettingsUpdate', (e) => {
        Object.assign(sysState, e.detail);
    });
    function logEvent(type, detail) {
        document.dispatchEvent(new CustomEvent('MaskaLogEvent', {
            detail: { type, detail, timestamp: Date.now() }
        }));
    }
    function getTargetResolution() {
        switch (sysState.qualityTarget) {
            case '1080p': return { width: 1080, height: 1920 };
            case '720p': return { width: 720, height: 1280 };
            default: return null;
        }
    }
    function getTargetShortSideRes() {
        switch (sysState.qualityTarget) {
            case '1080p': return 1080;
            case '720p': return 720;
            default: return null;
        }
    }
    const baseCreateObjectURL = URL.createObjectURL;
    Object.defineProperty(URL, 'createObjectURL', {
        get: function () {
            return function (obj) {
                if (sysState.active) {
                    logEvent('BLOCKED', 'createObjectURL blocked');
                    return 'data:application/octet-stream;base64,';
                }
                return baseCreateObjectURL(obj);
            };
        }
    });
    function processData(data) {
        if (!sysState.active) return null;
        let changed = false;
        const modifications = [];
        const targetRes = getTargetResolution();
        const targetShort = getTargetShortSideRes();
        if (data?.post_common_info?.post_type !== undefined) {
            const customType = localStorage.getItem('XY_POST_TYPE');
            if (customType) {
                data.post_common_info.post_type = parseInt(customType, 10);
                modifications.push(`post_type → ${customType}`);
                changed = true;
            } else if (data.post_common_info.post_type === 2) {
                data.post_common_info.post_type = 3;
                modifications.push('post_type 2 → 3 (edit→original)');
                changed = true;
            }
        }
        if (data?.feature_common_info_list) {
            data.feature_common_info_list.forEach((item, idx) => {
                if (item?.vedit_common_info?.draft !== undefined) {
                    delete item.vedit_common_info.draft;
                    modifications.push(`removed vedit draft [${idx}]`);
                    changed = true;
                }
            });
        }
        if (data?.single_post_req_list) {
            data.single_post_req_list.forEach((req, idx) => {
                const fInfo = req?.single_post_feature_info;
                if (fInfo) {
                    if (fInfo.vedit_segment_info) {
                        delete fInfo.vedit_segment_info;
                        modifications.push(`removed vedit_segment_info [${idx}]`);
                        changed = true;
                    }
                }
            });
        }
        function forceResolution(obj, path) {
            if (!obj || !targetRes) return;
            if (obj.width !== undefined && obj.height !== undefined) {
                const isPortrait = obj.height > obj.width;
                if (isPortrait) {
                    if (obj.width < targetRes.width) {
                        obj.width = targetRes.width;
                        obj.height = targetRes.height;
                        modifications.push(`${path} res → ${targetRes.width}x${targetRes.height}`);
                        changed = true;
                    }
                } else {
                    if (obj.height < targetRes.width) {
                        obj.width = targetRes.height;
                        obj.height = targetRes.width;
                        modifications.push(`${path} res → ${targetRes.height}x${targetRes.width}`);
                        changed = true;
                    }
                }
            }
            if (obj.resolution !== undefined && typeof obj.resolution === 'number' && targetShort) {
                if (obj.resolution < targetShort) {
                    obj.resolution = targetShort;
                    modifications.push(`${path}.resolution → ${targetShort}`);
                    changed = true;
                }
            }
            if (obj.short_side !== undefined && targetShort) {
                if (obj.short_side < targetShort) {
                    obj.short_side = targetShort;
                    modifications.push(`${path}.short_side → ${targetShort}`);
                    changed = true;
                }
            }
            if (obj.quality_level !== undefined) {
                obj.quality_level = 0;
                modifications.push(`${path}.quality_level → 0 (highest)`);
                changed = true;
            }
        }
        const videoInfoPaths = [
            data?.video_info,
            data?.post_common_info?.video_info,
            data?.media_info?.video_info,
            data?.upload_info?.video_info,
            data?.video,
            data?.media?.video
        ];
        videoInfoPaths.forEach((vi, i) => {
            if (vi) forceResolution(vi, `video_info[${i}]`);
        });
        if (data?.single_post_req_list) {
            data.single_post_req_list.forEach((req, idx) => {
                const fi = req?.single_post_feature_info;
                if (fi?.video_info) forceResolution(fi.video_info, `req[${idx}].video_info`);
                if (fi?.media_info?.video_info) forceResolution(fi.media_info.video_info, `req[${idx}].media.video_info`);
            });
        }
        function forceFPS(obj, path) {
            if (!obj || !sysState.fpsTarget || sysState.fpsTarget === 'original') return;
            const target = parseInt(sysState.fpsTarget, 10);
            if (isNaN(target)) return;
            const fpsKeys = ['fps', 'frame_rate', 'framerate', 'video_fps', 'target_fps'];
            fpsKeys.forEach(key => {
                if (obj[key] !== undefined && typeof obj[key] === 'number') {
                    if (obj[key] < target) {
                        obj[key] = target;
                        modifications.push(`${path}.${key} → ${target}`);
                        changed = true;
                    }
                }
            });
        }
        videoInfoPaths.forEach((vi, i) => {
            if (vi) forceFPS(vi, `video_info[${i}]`);
        });
        if (data?.single_post_req_list) {
            data.single_post_req_list.forEach((req, idx) => {
                const fi = req?.single_post_feature_info;
                if (fi?.video_info) forceFPS(fi.video_info, `req[${idx}].video_info`);
                if (fi?.media_info?.video_info) forceFPS(fi.media_info.video_info, `req[${idx}].media.video_info`);
            });
        }
        function forceCodec(obj, path) {
            if (!obj) return;
            const codecKeys = ['codec', 'video_codec', 'codec_type', 'encode_type'];
            codecKeys.forEach(key => {
                if (obj[key] !== undefined && obj[key] !== 'h264' && obj[key] !== 0) {
                    obj[key] = 'h264';
                    modifications.push(`${path}.${key} → h264`);
                    changed = true;
                }
            });
        }
        videoInfoPaths.forEach((vi, i) => {
            if (vi) forceCodec(vi, `video_info[${i}]`);
        });
        if (sysState.forceHighBitrate) {
            function forceBitrate(obj, path) {
                if (!obj) return;
                const brKeys = ['bitrate', 'video_bitrate', 'target_bitrate', 'max_bitrate'];
                brKeys.forEach(key => {
                    if (obj[key] !== undefined && typeof obj[key] === 'number') {
                        const minBr = sysState.qualityTarget === '1080p' ? 8000000 : 5000000;
                        if (obj[key] < minBr) {
                            obj[key] = minBr;
                            modifications.push(`${path}.${key} → ${(minBr / 1000000).toFixed(1)}Mbps`);
                            changed = true;
                        }
                    }
                });
                if (obj.bitrate_mode !== undefined) {
                    obj.bitrate_mode = 'vbr';
                    modifications.push(`${path}.bitrate_mode → vbr`);
                    changed = true;
                }
                if (obj.encode_bitrate_mode !== undefined) {
                    obj.encode_bitrate_mode = 0;
                    modifications.push(`${path}.encode_bitrate_mode → 0 (VBR)`);
                    changed = true;
                }
            }
            videoInfoPaths.forEach((vi, i) => {
                if (vi) forceBitrate(vi, `video_info[${i}]`);
            });
        }
        if (sysState.blockCompression) {
            function removeCompressionFields(obj, path) {
                if (!obj || typeof obj !== 'object') return;
                const keys = [
                    'compress_settings', 'compression_level', 'compress_type',
                    'compress_quality', 'compress_params', 'compression_info',
                    'client_compress', 'auto_compress'
                ];
                keys.forEach(key => {
                    if (obj[key] !== undefined) {
                        delete obj[key];
                        modifications.push(`removed ${path}.${key}`);
                        changed = true;
                    }
                });
                ['need_compress', 'should_compress', 'enable_compress', 'compress_enabled'].forEach(key => {
                    if (obj[key] !== undefined) {
                        obj[key] = false;
                        modifications.push(`${path}.${key} → false`);
                        changed = true;
                    }
                });
            }
            removeCompressionFields(data, 'root');
            videoInfoPaths.forEach((vi, i) => {
                if (vi) removeCompressionFields(vi, `video_info[${i}]`);
            });
            if (data?.single_post_req_list) {
                data.single_post_req_list.forEach((req, idx) => {
                    removeCompressionFields(req, `req[${idx}]`);
                    if (req?.single_post_feature_info) {
                        removeCompressionFields(req.single_post_feature_info, `req[${idx}].feat`);
                    }
                });
            }
        }
        if (sysState.blockTranscode) {
            function removeTranscodeFields(obj, path) {
                if (!obj || typeof obj !== 'object') return;
                const keys = [
                    'transcode_info', 'server_transcode', 'transcode_type',
                    'transcode_params', 'transcode_settings', 'auto_transcode',
                    'server_side_encode', 'server_encode_params'
                ];
                keys.forEach(key => {
                    if (obj[key] !== undefined) {
                        delete obj[key];
                        modifications.push(`removed ${path}.${key}`);
                        changed = true;
                    }
                });
                ['need_transcode', 'should_transcode', 'enable_transcode'].forEach(key => {
                    if (obj[key] !== undefined) {
                        obj[key] = false;
                        modifications.push(`${path}.${key} → false`);
                        changed = true;
                    }
                });
            }
            removeTranscodeFields(data, 'root');
            if (data?.single_post_req_list) {
                data.single_post_req_list.forEach((req, idx) => {
                    removeTranscodeFields(req, `req[${idx}]`);
                    if (req?.single_post_feature_info) {
                        removeTranscodeFields(req.single_post_feature_info, `req[${idx}].feat`);
                    }
                });
            }
        }
        if (sysState.removeWatermark) {
            function removeWatermarkFields(obj, path) {
                if (!obj || typeof obj !== 'object') return;
                const keys = [
                    'watermark_info', 'watermark', 'watermark_type',
                    'add_watermark', 'watermark_params', 'watermark_enabled',
                    'enable_watermark', 'watermark_config'
                ];
                keys.forEach(key => {
                    if (obj[key] !== undefined) {
                        delete obj[key];
                        modifications.push(`removed ${path}.${key}`);
                        changed = true;
                    }
                });
            }
            removeWatermarkFields(data, 'root');
            if (data?.single_post_req_list) {
                data.single_post_req_list.forEach((req, idx) => {
                    removeWatermarkFields(req, `req[${idx}]`);
                    if (req?.single_post_feature_info) {
                        removeWatermarkFields(req.single_post_feature_info, `req[${idx}].feat`);
                    }
                });
            }
        }
        if (sysState.preserveHDR) {
            videoInfoPaths.forEach((vi, i) => {
                if (!vi) return;
                if (vi.hdr_info?.need_convert !== undefined) {
                    vi.hdr_info.need_convert = false;
                    modifications.push(`video_info[${i}].hdr_info.need_convert → false`);
                    changed = true;
                }
            });
        }
        ['cover_generation_params', 'cover_info', 'auto_cover',
            'cover_generation_type', 'need_cover_generation'].forEach(key => {
                if (data?.[key] !== undefined) {
                    delete data[key];
                    modifications.push(`removed root.${key}`);
                    changed = true;
                }
            });
        function forceQualityParams(obj, path) {
            if (!obj) return;
            ['quality_level', 'encode_quality', 'video_quality', 'target_quality', 'quality'].forEach(key => {
                if (obj[key] !== undefined) {
                    obj[key] = typeof obj[key] === 'string' ? 'high' : 0;
                    modifications.push(`${path}.${key} → max`);
                    changed = true;
                }
            });
            ['quality_downgrade', 'auto_quality', 'adaptive_quality',
                'quality_optimize', 'quality_adapt', 'degrade_quality'].forEach(key => {
                    if (obj[key] !== undefined) {
                        delete obj[key];
                        modifications.push(`removed ${path}.${key}`);
                        changed = true;
                    }
                });
        }
        forceQualityParams(data, 'root');
        videoInfoPaths.forEach((vi, i) => {
            if (vi) forceQualityParams(vi, `video_info[${i}]`);
        });
        function deepScanAndFix(obj, path, depth) {
            if (!obj || typeof obj !== 'object' || depth > 5) return;
            for (const key of Object.keys(obj)) {
                const val = obj[key];
                if ((key === 'fps' || key === 'frame_rate' || key === 'framerate') && typeof val === 'number') {
                    const target = parseInt(sysState.fpsTarget, 10);
                    if (!isNaN(target) && val < target && val > 0) {
                        obj[key] = target;
                        modifications.push(`deep: ${path}.${key} ${val} → ${target}`);
                        changed = true;
                    }
                }
                if ((key === 'short_side' || key === 'resolution') && typeof val === 'number' && targetShort) {
                    if (val < targetShort && val > 0) {
                        obj[key] = targetShort;
                        modifications.push(`deep: ${path}.${key} ${val} → ${targetShort}`);
                        changed = true;
                    }
                }
                if (val && typeof val === 'object' && !Array.isArray(val)) {
                    deepScanAndFix(val, `${path}.${key}`, depth + 1);
                }
                if (Array.isArray(val)) {
                    val.forEach((item, i) => {
                        if (item && typeof item === 'object') {
                            deepScanAndFix(item, `${path}.${key}[${i}]`, depth + 1);
                        }
                    });
                }
            }
        }
        deepScanAndFix(data, 'root', 0);
        if (changed && modifications.length > 0) {
            logEvent('MODIFIED', `project/post — ${modifications.length} changes: ${modifications.join(', ')}`);
        }
        return changed ? JSON.stringify(data) : null;
    }
    window.fetch = new Proxy(window.fetch, {
        apply: function (target, thisArg, args) {
            const [url, config] = args;
            if (typeof url === 'string' && config?.body) {
                if (url.includes('project/post') ||
                    url.includes('/publish') ||
                    url.includes('/post/publish')) {
                    try {
                        const parsed = JSON.parse(config.body);
                        const newBody = processData(parsed);
                        if (newBody) {
                            config.body = newBody;
                            document.dispatchEvent(new CustomEvent('MaskaStatEvent', { detail: 'intercept' }));
                        }
                    } catch (e) { }
                }
            }
            return Reflect.apply(target, thisArg, args);
        }
    });
    const origXHROpen = XMLHttpRequest.prototype.open;
    const origXHRSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url, ...rest) {
        this.__maskaUrl = url;
        return origXHROpen.call(this, method, url, ...rest);
    };
    XMLHttpRequest.prototype.send = function (body) {
        if (this.__maskaUrl && typeof this.__maskaUrl === 'string' && typeof body === 'string') {
            if (this.__maskaUrl.includes('project/post') ||
                this.__maskaUrl.includes('/publish') ||
                this.__maskaUrl.includes('/post/publish')) {
                try {
                    const parsed = JSON.parse(body);
                    const newBody = processData(parsed);
                    if (newBody) {
                        body = newBody;
                        document.dispatchEvent(new CustomEvent('MaskaStatEvent', { detail: 'intercept' }));
                    }
                } catch (e) { }
            }
        }
        return origXHRSend.call(this, body);
    };
    logEvent('INIT', 'MASKA V2 interception engine loaded — all systems ready');
})();