function setMsg(t) { document.getElementById('msg').textContent = t; }
function setBar(pct) { document.getElementById('bar').style.width = Math.min(pct,100)+'%'; }

chrome.runtime.sendMessage({ source: 'maska-tc-bg', type: 'ready' });
setMsg('READY · AWAITING FILE');

chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.source !== 'maska-tc-data') return;
    doTranscode(msg.buffer, msg.tw, msg.th);
});

async function doTranscode(inputBuffer, tw, th) {
    try {
        const blob = new Blob([inputBuffer], { type: 'video/mp4' });
        const url = URL.createObjectURL(blob);

        const video = document.createElement('video');
        video.muted = true;
        video.playsInline = true;
        video.src = url;
        document.body.appendChild(video);

        await new Promise((res, rej) => { video.onloadedmetadata = res; video.onerror = rej; });

        const duration = video.duration;
        setMsg(`TRANSCODING ${video.videoWidth}×${video.videoHeight} → ${tw}×${th}`);
        setBar(0);

        const canvas = document.createElement('canvas');
        canvas.width = tw;
        canvas.height = th;
        const ctx = canvas.getContext('2d');

        const stream = canvas.captureStream(0);
        const track = stream.getVideoTracks()[0];

        const mimeTypes = ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm'];
        const mimeType = mimeTypes.find(m => MediaRecorder.isTypeSupported(m)) || 'video/webm';

        const recorder = new MediaRecorder(stream, {
            mimeType,
            videoBitsPerSecond: 12_000_000
        });

        const chunks = [];
        recorder.ondataavailable = e => { if (e.data.size > 0) chunks.push(e.data); };
        recorder.start(50);

        await new Promise((resolve, reject) => {
            video.onerror = reject;

            const onFrame = (now, meta) => {
                ctx.drawImage(video, 0, 0, tw, th);
                track.requestFrame();

                const pct = Math.min(Math.round((meta.mediaTime / duration) * 100), 99);
                setBar(pct);
                setMsg(`TRANSCODING... ${pct}%`);
                chrome.runtime.sendMessage({ source: 'maska-tc-bg', type: 'progress', value: pct });

                if (!video.ended) {
                    video.requestVideoFrameCallback(onFrame);
                } else {
                    setTimeout(resolve, 300);
                }
            };

            video.requestVideoFrameCallback(onFrame);
            video.play().catch(reject);
            video.onended = () => setTimeout(resolve, 400);
        });

        recorder.stop();
        await new Promise(res => { recorder.onstop = res; });

        setBar(100);
        setMsg('COMPLETE');
        URL.revokeObjectURL(url);
        document.body.removeChild(video);

        const outBlob = new Blob(chunks, { type: mimeType });
        const outBuffer = await outBlob.arrayBuffer();

        chrome.runtime.sendMessage({ source: 'maska-tc-bg', type: 'done', buffer: outBuffer });

    } catch (e) {
        chrome.runtime.sendMessage({ source: 'maska-tc-bg', type: 'error', message: e.message });
    }
}
