let isInjected = false;

function checkAndInject() {
    if (isInjected) return;
    injectScript();
    isInjected = true;
}

function injectScript() {
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('inject.js');
    s.onload = function() { this.remove(); };
    (document.head || document.documentElement).appendChild(s);
}

checkAndInject();
const urlObserver = new MutationObserver(() => { checkAndInject(); });
if (document.body) urlObserver.observe(document.body, { childList: true, subtree: true });

const MM_UPLOAD_URL = 'https://www.tiktok.com/tiktokstudio/upload?from=creator_center';

function mmIsUploadPage() {
    const u = location.href;
    return u.includes('/upload') ||
        u.includes('/creator-center') ||
        u.includes('/studio');
}

function mmMountFloatingPanel() {
    if (document.getElementById('mm-float-host')) return;

    const host = document.createElement('div');
    host.id = 'mm-float-host';
    host.setAttribute('data-maska-method', '1');
    Object.assign(host.style, {
        position: 'fixed',
        zIndex: '2147483646',
        top: '0',
        left: '0',
        width: '0',
        height: '0',
        pointerEvents: 'none'
    });

    const root = document.createElement('div');
    Object.assign(root.style, {
        position: 'fixed',
        top: '96px',
        right: '20px',
        left: 'auto',
        pointerEvents: 'auto',
        fontFamily: "'DM Sans', system-ui, sans-serif",
        boxSizing: 'border-box',
        borderRadius: '12px',
        overflow: 'hidden',
        boxShadow: '0 12px 48px rgba(0,0,0,0.55), 0 0 0 1px rgba(200,255,0,0.15)',
        background: '#0C0C0C'
    });

    let minimized = true;

    const handle = document.createElement('div');
    handle.setAttribute('data-mm-drag', '1');
    Object.assign(handle.style, {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '8px',
        padding: '10px 10px 10px 14px',
        background: '#141414',
        borderBottom: '1px solid rgba(255,255,255,0.07)',
        cursor: 'grab',
        userSelect: 'none',
        flexShrink: '0'
    });

    const handleLeft = document.createElement('div');
    Object.assign(handleLeft.style, {
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        flex: '1',
        minWidth: '0'
    });
    const titleSpan = document.createElement('span');
    titleSpan.textContent = 'MASKA METHOD';
    Object.assign(titleSpan.style, {
        fontFamily: 'ui-monospace, monospace',
        fontSize: '10px',
        fontWeight: '700',
        letterSpacing: '0.12em',
        color: '#C8FF00'
    });
    const gripSpan = document.createElement('span');
    gripSpan.textContent = '⋮⋮';
    Object.assign(gripSpan.style, { fontSize: '11px', color: '#555', letterSpacing: '2px' });
    handleLeft.appendChild(titleSpan);
    handleLeft.appendChild(gripSpan);

    const minToggle = document.createElement('button');
    minToggle.type = 'button';
    Object.assign(minToggle.style, {
        flexShrink: '0',
        width: '28px',
        height: '28px',
        padding: '0',
        margin: '0',
        border: '1px solid rgba(255,255,255,0.12)',
        borderRadius: '6px',
        background: 'rgba(255,255,255,0.04)',
        color: '#888',
        fontSize: '16px',
        lineHeight: '1',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'system-ui, sans-serif'
    });
    minToggle.addEventListener('mousedown', (e) => e.stopPropagation());
    minToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        minimized = !minimized;
        chrome.storage.local.set({ mm_panel_minimized: minimized });
        applyPanelLayout();
    });

    handle.appendChild(handleLeft);
    handle.appendChild(minToggle);

    const body = document.createElement('div');
    Object.assign(body.style, {
        position: 'relative',
        width: '100%',
        height: mmIsUploadPage() ? 'calc(100% - 40px)' : 'auto',
        minHeight: mmIsUploadPage() ? '0' : '120px',
        background: '#0C0C0C'
    });

    let iframe = null;
    const uploadBtnWrap = document.createElement('div');
    Object.assign(uploadBtnWrap.style, {
        display: mmIsUploadPage() ? 'none' : 'flex',
        flexDirection: 'column',
        alignItems: 'stretch',
        padding: '20px 18px 22px',
        gap: '12px'
    });
    const hint = document.createElement('p');
    hint.textContent = 'Open the upload screen to use Force FPS and video inject.';
    Object.assign(hint.style, {
        margin: '0',
        fontSize: '11px',
        lineHeight: '1.5',
        color: '#666',
        fontWeight: '300'
    });
    const uploadBtn = document.createElement('button');
    uploadBtn.type = 'button';
    uploadBtn.textContent = 'Upload Now';
    Object.assign(uploadBtn.style, {
        width: '100%',
        padding: '12px 16px',
        border: '1px solid rgba(200,255,0,0.35)',
        borderRadius: '8px',
        background: 'transparent',
        color: '#C8FF00',
        fontFamily: 'Space Mono, monospace',
        fontSize: '11px',
        fontWeight: '700',
        letterSpacing: '0.14em',
        cursor: 'pointer',
        textTransform: 'uppercase',
        transition: 'background 0.2s, color 0.2s'
    });
    uploadBtn.onmouseenter = () => {
        uploadBtn.style.background = '#C8FF00';
        uploadBtn.style.color = '#0C0C0C';
    };
    uploadBtn.onmouseleave = () => {
        uploadBtn.style.background = 'transparent';
        uploadBtn.style.color = '#C8FF00';
    };
    uploadBtn.addEventListener('click', () => {
        location.href = MM_UPLOAD_URL;
    });
    uploadBtnWrap.appendChild(hint);
    uploadBtnWrap.appendChild(uploadBtn);

    function ensureIframe() {
        if (iframe || !mmIsUploadPage()) return;
        iframe = document.createElement('iframe');
        iframe.src = chrome.runtime.getURL('popup.html');
        iframe.setAttribute('title', 'Maska Method');
        Object.assign(iframe.style, {
            width: '100%',
            height: '100%',
            border: 'none',
            display: 'block',
            background: '#0C0C0C'
        });
        body.appendChild(iframe);
    }

    if (mmIsUploadPage()) {
        ensureIframe();
    } else {
        body.appendChild(uploadBtnWrap);
    }

    function applyPanelLayout() {
        const onUpload = mmIsUploadPage();
        minToggle.textContent = minimized ? '+' : '−';
        minToggle.setAttribute('aria-label', minimized ? 'Expand panel' : 'Minimize panel');

        body.style.display = minimized ? 'none' : 'block';
        handle.style.borderBottom = minimized ? 'none' : '1px solid rgba(255,255,255,0.07)';

        if (onUpload) ensureIframe();

        if (minimized) {
            root.style.width = 'auto';
            root.style.height = 'auto';
            root.style.minWidth = '172px';
        } else {
            root.style.minWidth = '';
            root.style.width = onUpload ? '340px' : '280px';
            root.style.height = onUpload ? '580px' : 'auto';
            body.style.height = onUpload ? 'calc(100% - 40px)' : 'auto';
            body.style.minHeight = onUpload ? '0' : '120px';
            uploadBtnWrap.style.display = onUpload ? 'none' : 'flex';
            if (onUpload) {
                if (iframe) iframe.style.display = 'block';
            } else if (iframe) {
                iframe.style.display = 'none';
            }
        }
    }

    root.appendChild(handle);
    root.appendChild(body);
    host.appendChild(root);

    const anchor = document.body || document.documentElement;
    anchor.appendChild(host);

    applyPanelLayout();

    chrome.storage.local.get(['mm_panel_pos', 'mm_panel_minimized'], (r) => {
        if (r.mm_panel_minimized === false) minimized = false;
        else minimized = true;
        applyPanelLayout();
        const p = r.mm_panel_pos;
        if (p && typeof p.left === 'number' && typeof p.top === 'number') {
            root.style.right = 'auto';
            root.style.left = `${p.left}px`;
            root.style.top = `${p.top}px`;
        }
    });

    let drag = null;
    function onMove(e) {
        if (!drag) return;
        const w = root.offsetWidth;
        const h = root.offsetHeight;
        let nx = e.clientX - drag.ox;
        let ny = e.clientY - drag.oy;
        nx = Math.max(8, Math.min(nx, window.innerWidth - w - 8));
        ny = Math.max(8, Math.min(ny, window.innerHeight - h - 8));
        root.style.left = `${nx}px`;
        root.style.top = `${ny}px`;
        root.style.right = 'auto';
        drag.x = nx;
        drag.y = ny;
    }
    function onUp() {
        if (!drag) return;
        drag = null;
        handle.style.cursor = 'grab';
        const left = parseInt(root.style.left, 10) || 0;
        const top = parseInt(root.style.top, 10) || 0;
        chrome.storage.local.set({ mm_panel_pos: { left, top } });
        document.removeEventListener('mousemove', onMove, true);
        document.removeEventListener('mouseup', onUp, true);
    }
    handle.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return;
        const rect = root.getBoundingClientRect();
        drag = {
            ox: e.clientX - rect.left,
            oy: e.clientY - rect.top,
            x: rect.left,
            y: rect.top
        };
        handle.style.cursor = 'grabbing';
        document.addEventListener('mousemove', onMove, true);
        document.addEventListener('mouseup', onUp, true);
        e.preventDefault();
    });

    function mmRefreshPanelMode() {
        applyPanelLayout();
    }

    let lastHref = location.href;
    function mmCheckUrl() {
        if (location.href !== lastHref) {
            lastHref = location.href;
            mmRefreshPanelMode();
        }
    }
    const origPush = history.pushState;
    const origReplace = history.replaceState;
    history.pushState = function () {
        const ret = origPush.apply(this, arguments);
        setTimeout(mmCheckUrl, 0);
        return ret;
    };
    history.replaceState = function () {
        const ret = origReplace.apply(this, arguments);
        setTimeout(mmCheckUrl, 0);
        return ret;
    };
    window.addEventListener('popstate', () => setTimeout(mmCheckUrl, 0));
    setInterval(mmCheckUrl, 800);
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mmMountFloatingPanel);
} else {
    mmMountFloatingPanel();
}

let warningEl = null;
let guardObserver = null;

function isHighRes(text) {
    if (!text) return false;
    const t = text.toUpperCase().replace(/\s/g, '');
    return t.includes('1440') || t.includes('2160') ||
           t.includes('2.7K') || t.includes('2K')   ||
           t.includes('4K')   || t.includes('8K');
}

function getResLabel() {
    let el = document.querySelector('.resolution-label-text');
    if (!el) el = document.querySelector('[class*="resolution-label"]');
    if (!el) el = document.querySelector('[class*="resolution_label"]');
    if (!el) el = document.querySelector('[class*="ResolutionLabel"]');
    if (!el) {
        const all = document.querySelectorAll('div, span');
        for (const node of all) {
            if (/^(1080P|1440P|2K|4K|2160P|720P|480P|360P|2\.7K|8K)$/i.test(node.textContent.trim())) {
                el = node; break;
            }
        }
    }
    return el ? el.textContent.trim() : null;
}

function crashPage(resText) {
    document.open();
    document.write(`<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Maska Method — Resolution Error</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body {
    width: 100%; height: 100%;
    background: #0a0a0a;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Space Mono', 'Courier New', monospace;
    overflow: hidden;
  }
  body::before {
    content: '';
    position: fixed; inset: 0;
    background-image:
      linear-gradient(rgba(255,45,85,0.04) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255,45,85,0.04) 1px, transparent 1px);
    background-size: 32px 32px;
    pointer-events: none;
    z-index: 0;
  }
  .box {
    position: relative; z-index: 1;
    text-align: center;
    padding: 60px 52px;
    border: 1px solid rgba(255,45,85,0.35);
    border-radius: 20px;
    background: rgba(15,15,15,0.95);
    box-shadow: 0 0 100px rgba(255,45,85,0.15), inset 0 0 40px rgba(255,45,85,0.03);
    max-width: 480px; width: 90%;
    animation: popin 0.4s cubic-bezier(0.175,0.885,0.32,1.275) both;
  }
  @keyframes popin {
    from { transform: scale(0.85); opacity: 0; }
    to   { transform: scale(1);    opacity: 1; }
  }
  .icon {
    width: 64px; height: 64px;
    margin: 0 auto 28px;
    animation: pulse 2.2s ease-in-out infinite;
  }
  @keyframes pulse {
    0%,100% { filter: drop-shadow(0 0 8px rgba(255,45,85,0.5)); }
    50%      { filter: drop-shadow(0 0 28px rgba(255,45,85,1)); }
  }
  .title {
    font-size: 20px; font-weight: 700;
    letter-spacing: 0.06em;
    color: #FF2D55;
    text-shadow: 0 0 24px rgba(255,45,85,0.5);
    text-transform: uppercase;
    margin-bottom: 16px;
    line-height: 1.3;
  }
  .sub {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-size: 14px; color: #666;
    line-height: 1.8; margin-bottom: 32px;
  }
  .sub strong { color: #FF2D55; }
  .badge {
    display: inline-flex; align-items: center; gap: 14px;
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 10px; padding: 13px 24px;
    margin-bottom: 32px;
  }
  .badge-cur  { font-size: 20px; font-weight: 700; color: #FF2D55; letter-spacing: 0.1em; }
  .badge-arr  { font-size: 16px; color: #333; }
  .badge-tgt  { font-size: 20px; font-weight: 700; color: #C8FF00; letter-spacing: 0.1em; }
  .btn {
    display: inline-block;
    padding: 13px 32px;
    background: transparent;
    border: 1px solid rgba(200,255,0,0.3);
    border-radius: 8px;
    font-family: 'Space Mono', 'Courier New', monospace;
    font-size: 11px; font-weight: 700;
    letter-spacing: 0.14em;
    color: #C8FF00;
    cursor: pointer;
    text-transform: uppercase;
    transition: all 0.2s;
    text-decoration: none;
  }
  .btn-green { border-color: rgba(200,255,0,0.5); color: #C8FF00; margin-bottom: 0; }
  .btn-green:hover { background: #C8FF00; color: #0a0a0a; box-shadow: 0 0 24px rgba(200,255,0,0.4); }
  .btn:hover {
    background: #C8FF00;
    color: #0a0a0a;
    box-shadow: 0 0 24px rgba(200,255,0,0.35);
  }
  .footer {
    margin-top: 28px;
    font-size: 9px; letter-spacing: 0.12em;
    color: #2a2a2a;
  }
</style>
</head>
<body>
<div class="box">
  <svg class="icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 3L2 21h20L12 3z" fill="rgba(255,45,85,0.1)" stroke="#FF2D55" stroke-width="1.5" stroke-linejoin="round"/>
    <line x1="12" y1="9" x2="12" y2="14" stroke="#FF2D55" stroke-width="2.5" stroke-linecap="round"/>
    <circle cx="12" cy="17.5" r="1.3" fill="#FF2D55"/>
  </svg>
  <div class="title">Make sure your video is 1080P</div>
  <div class="sub">
    Your video is <strong>${resText.toUpperCase()}</strong>.<br>
    Uploading 2K / 4K is bannable on TikTok.<br>
    Re-export at 1080P.
  </div>
  <div class="badge">
    <span class="badge-cur">${resText.toUpperCase()}</span>
    <span class="badge-arr">→</span>
    <span class="badge-tgt">1080P</span>
  </div>
  <br>
  <div style="font-family:-apple-system,sans-serif;font-size:12px;color:#555;margin-bottom:10px;letter-spacing:0.03em;">Turn your video to 1080P here:</div>
  <a class="btn btn-green" href="https://maska.dev/maska-hub" target="_blank">
    TURN YOUR VIDEO TO 1080P HERE
  </a>
  <br><br>
  <a class="btn" href="https://www.tiktok.com/tiktokstudio/upload?from=creator_center">
    ← GO BACK &amp; RE-UPLOAD
  </a>
  <div class="footer">MASKA METHOD · RESOLUTION GUARD</div>
</div>
</body>
</html>`);
    document.close();
}

function runCheck() {
    const res = getResLabel();
    if (res && isHighRes(res)) {
        crashPage(res);
        if (guardObserver) { guardObserver.disconnect(); guardObserver = null; }
    }
}

function startGuard() {
    if (guardObserver) return;
    runCheck();
    const poll = setInterval(() => {
        const res = getResLabel();
        if (res && isHighRes(res)) {
            clearInterval(poll);
            crashPage(res);
        }
    }, 800);
    guardObserver = new MutationObserver(runCheck);
    guardObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
}

if (document.body) {
    startGuard();
} else {
    document.addEventListener('DOMContentLoaded', startGuard);
}
