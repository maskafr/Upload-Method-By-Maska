let activeTranscoderTabId = null;
let activePopupId = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    if (msg.action === 'TC_SEND') {
        activeTranscoderTabId = msg.tabId;
        chrome.tabs.sendMessage(msg.tabId, {
            source: 'maska-tc-data',
            buffer: msg.buffer,
            tw: msg.tw,
            th: msg.th
        });
        return;
    }

    if (msg.source === 'maska-tc-bg') {
        chrome.runtime.sendMessage(msg).catch(() => {});
        return;
    }

    if (msg.action === 'FETCH_HD_VIDEO') {
        handleHDProcess(msg.url)
            .then(link => {
                if (link) sendResponse({ success: true, data: { playUrl: link } });
                else sendResponse({ success: false });
            })
            .catch(() => sendResponse({ success: false }));
        return true;
    }

    if (msg.action === 'DOWNLOAD_MEDIA') {
        chrome.downloads.download({
            url: msg.url,
            filename: `maska_downloads/${msg.filename}`,
            saveAs: false
        });
    }
});

async function handleHDProcess(tiktokUrl) {
    try {
        const r = await fetch('https://www.tikwm.com/api/video/task/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': 'https://www.tikwm.com/originalDownloader.html',
                'Origin': 'https://www.tikwm.com'
            },
            body: `url=${encodeURIComponent(tiktokUrl)}&web=1`
        });
        const data = await r.json();
        if (data.code === 0 && data.data && data.data.task_id) {
            await new Promise(res => setTimeout(res, 2000));
            return await checkTaskResult(data.data.task_id);
        }
        return null;
    } catch { return null; }
}

async function checkTaskResult(taskId) {
    try {
        const r = await fetch(`https://www.tikwm.com/api/video/task/result?task_id=${taskId}`);
        const json = await r.json();
        if (json.code === 0 && json.data) {
            const d = json.data.detail || json.data;
            return d.play_url || d.download_url || d.play || null;
        }
        return null;
    } catch { return null; }
}
