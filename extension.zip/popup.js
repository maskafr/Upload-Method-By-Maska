const $ = id => document.getElementById(id);

const MM_ELST_BYPASS_PAYLOAD = 268435457;

let selectedFile = null;
let isProcessing = false;
let videoWidth = 0, videoHeight = 0;

const toggleBtn = $('toggleBtn');
const statusPill = $('statusPill');
const statusText = $('statusText');
const flag60 = $('flag60');
const flagLossless = $('flagLossless');
const flagPromo = $('flagPromo');
const uploadZone = $('uploadZone');
const uploadTextEl = $('uploadText');
const fileInput = $('bypassFileInput');
const startBtn = $('startBypassBtn');
const terminal = $('terminal');
const loadingOverlay = $('loadingOverlay');
const loadPct = $('loadPct');
const loadRingLabel = $('loadRingLabel');
const loadPhase = $('loadPhase');
const loadSub = $('loadSub');
const loadElapsed = $('loadElapsed');
const loadETA = $('loadETA');
const loadBar = $('loadBar');
const ringCanvas = $('ringCanvas');
const ringCtx = ringCanvas.getContext('2d');

let loadStartTime = 0;
let loadTimerInterval = null;
let currentPct = 0;

function showOverlay(phaseLabel) {
    currentPct = 0;
    loadStartTime = Date.now();
    loadingOverlay.classList.add('show');
    setPhase(1, phaseLabel || 'INITIALIZING', '');
    updateRing(0);
    loadBar.style.width = '0%';
    loadPct.textContent = '0%';
    loadElapsed.textContent = '0:00';
    loadETA.textContent = '—';
    const pdots = ['pdot1', 'pdot2', 'pdot3'].map(id => $(id)).filter(Boolean);
    pdots.forEach(el => el.className = 'pdot');
    const plines = ['pline1', 'pline2'].map(id => $(id)).filter(Boolean);
    plines.forEach(el => el.className = 'phase-line');
    clearInterval(loadTimerInterval);
    loadTimerInterval = setInterval(tickTimer, 500);
}

function hideOverlay() {
    loadingOverlay.classList.remove('show');
    clearInterval(loadTimerInterval);
}

function tickTimer() {
    const elapsed = Math.floor((Date.now() - loadStartTime) / 1000);
    loadElapsed.textContent = fmt(elapsed);
    if (currentPct > 2 && currentPct < 99) {
        const rate = currentPct / Math.max(1, elapsed);
        const rem = Math.max(0, Math.ceil((100 - currentPct) / rate));
        loadETA.textContent = fmt(rem);
    } else if (currentPct >= 99) {
        loadETA.textContent = '0:00';
    }
}

function fmt(s) {
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function setProgress(pct, sub) {
    currentPct = Math.min(pct, 100);
    updateRing(currentPct);
    loadBar.style.width = currentPct + '%';
    loadPct.textContent = Math.round(currentPct) + '%';
    if (sub) loadSub.textContent = sub;
}

function setPhase(phase, label, sub) {
    loadPhase.textContent = label;
    if (sub !== undefined) loadSub.textContent = sub;
    loadRingLabel.textContent = ['', 'CLOUD', 'PATCH', 'INJECT'][phase] || '';
    for (let i = 1; i <= 3; i++) {
        const d = $('pdot' + i);
        if (d) d.className = i < phase ? 'pdot done' : i === phase ? 'pdot active' : 'pdot';
    }
    for (let i = 1; i <= 2; i++) {
        const pl = $('pline' + i);
        if (pl) pl.className = i < phase ? 'phase-line done' : 'phase-line';
    }
}

function updateRing(pct) {
    const cx = 48, cy = 48, r = 42;
    ringCtx.clearRect(0, 0, 96, 96);
    ringCtx.beginPath();
    ringCtx.arc(cx, cy, r, 0, Math.PI * 2);
    ringCtx.strokeStyle = 'rgba(255,255,255,0.05)';
    ringCtx.lineWidth = 4;
    ringCtx.stroke();
    if (pct > 0) {
        const s = -Math.PI / 2;
        const e = s + (pct / 100) * Math.PI * 2;
        ringCtx.beginPath();
        ringCtx.arc(cx, cy, r, s, e);
        ringCtx.strokeStyle = '#C8FF00';
        ringCtx.lineWidth = 4;
        ringCtx.lineCap = 'round';
        ringCtx.stroke();
    }
}

function tLog(msg, type = 'normal') {
}

function updateToggleUI(on) {
    statusPill.classList.toggle('on', on);
    statusText.textContent = on ? 'ACTIVE' : 'STANDBY';
}

toggleBtn.addEventListener('change', async () => {
    const on = toggleBtn.checked;
    updateToggleUI(on);
    chrome.storage.local.set({ mm_60fps_active: on });
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url?.includes('tiktok.com')) return;
    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        world: 'MAIN',
        func: (a) => { a ? window.activate60FPS?.() : window.reset60FPS?.(); },
        args: [on]
    }).catch(() => { });
});

(async () => {
    const r = await chrome.storage.local.get('mm_60fps_active');
    if (r.mm_60fps_active === true) {
        toggleBtn.checked = true;
        updateToggleUI(true);
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.url?.includes('tiktok.com') &&
            (tab.url.includes('/upload') || tab.url.includes('/creator-center') || tab.url.includes('/studio'))) {
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: 'MAIN',
                func: () => window.activate60FPS?.()
            }).catch(() => { });
        }
    }
})();

uploadZone.addEventListener('click', () => { if (!isProcessing) fileInput.click(); });

fileInput.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    selectedFile = file;

    uploadTextEl.textContent = file.name.length > 22 ? file.name.slice(0, 19) + '...' : file.name;
    uploadZone.classList.add('has-file');
    uploadZone.classList.remove('processing');
    ['b-res', 'b-fps', 'b-bitrate', 'b-size'].forEach(id => $(id).textContent = '—');

    tLog('Scanning binary structure...', 'highlight');
    const totalFrames = await extractRealFPS(file);

    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
        videoWidth = video.videoWidth;
        videoHeight = video.videoHeight;
        const sizeMB = (file.size / 1048576).toFixed(1);
        const bitrate = video.duration > 0
            ? ((file.size * 8) / video.duration / 1e6).toFixed(1)
            : 0;
        const fps = (totalFrames && video.duration > 0)
            ? Math.round(totalFrames / video.duration)
            : '?';



        $('b-res').textContent = `${videoWidth}×${videoHeight}`;
        $('b-fps').textContent = `${fps}`;
        $('b-bitrate').textContent = `${bitrate}`;
        $('b-size').textContent = `${sizeMB}`;

        tLog(`${videoWidth}×${videoHeight} · ${fps}fps · ${bitrate}Mbps`, 'normal');
        tLog(`Ready: ${file.name.slice(0, 20)}`, 'highlight');

        startBtn.disabled = false;
        startBtn.classList.add('ready');
        if (Math.max(videoWidth, videoHeight) > 1920 || Math.min(videoWidth, videoHeight) > 1080) {
            startBtn.textContent = 'Downscale';
            startBtn.dataset.action = 'downscale';
        } else {
            startBtn.textContent = 'Post it !';
            startBtn.dataset.action = 'post';
        }
    };
    video.src = URL.createObjectURL(file);
});

async function extractRealFPS(file) {
    return new Promise(resolve => {
        const reader = new FileReader();
        reader.onload = e => {
            try {
                const buf = e.target.result;
                const view = new DataView(buf);
                const u8 = new Uint8Array(buf);
                const vide = [0x76, 0x69, 0x64, 0x65];
                const stsz = [0x73, 0x74, 0x73, 0x7A];
                let vi = -1;
                for (let i = 0; i < u8.length - 4; i++) {
                    if (u8[i] === vide[0] && u8[i + 1] === vide[1] &&
                        u8[i + 2] === vide[2] && u8[i + 3] === vide[3]) { vi = i; break; }
                }
                if (vi !== -1) {
                    for (let i = vi; i < u8.length - 4; i++) {
                        if (u8[i] === stsz[0] && u8[i + 1] === stsz[1] &&
                            u8[i + 2] === stsz[2] && u8[i + 3] === stsz[3]) {
                            resolve(view.getUint32(i + 12)); return;
                        }
                    }
                }
            } catch { }
            resolve(null);
        };
        reader.readAsArrayBuffer(file.slice(0, 157286400));
    });
}



function bufferToDataURL(arrayBuffer) {
    return new Promise(resolve => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.readAsDataURL(new Blob([arrayBuffer], { type: 'video/mp4' }));
    });
}

async function injectIntoTikTok(dataUrl, fileName) {
    try {
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        const file = new File([blob], fileName, { type: 'video/mp4' });

        const input =
            document.querySelector('input[type="file"][accept*="video"]') ||
            document.querySelector('input[type="file"]');

        if (!input) return { ok: false, error: 'File input not found on page' };

        const tracker = input._valueTracker;
        if (tracker) tracker.setValue('');

        const dt = new DataTransfer();
        dt.items.add(file);
        input.files = dt.files;

        input.dispatchEvent(new Event('change', { bubbles: true }));
        input.dispatchEvent(new Event('input', { bubbles: true }));

        return { ok: true };
    } catch (err) {
        return { ok: false, error: err.message };
    }
}

startBtn.addEventListener('click', async () => {
    if (!selectedFile || isProcessing) return;

    if (startBtn.dataset.action === 'downscale') {
        chrome.tabs.create({ url: 'https://maska.dev/maska-hub/ext-compress/' });
        return;
    }

    isProcessing = true;
    startBtn.disabled = true;
    startBtn.classList.remove('ready');
    uploadZone.classList.add('processing');
    uploadZone.classList.remove('has-file');
    showOverlay('PATCH');
    let fileToProcess = selectedFile;

    setPhase(1, 'BYPASS PAYLOAD', 'Applying elst value...');
    tLog('Built-in bypass payload', 'normal');
    setProgress(70, 'Payload ready');

    try {
        const config = { payload: MM_ELST_BYPASS_PAYLOAD };

        setProgress(78, 'Payload ready');

        setPhase(2, 'BINARY PATCH', 'Writing elst payload...');
        tLog('Patching binary...', 'normal');
        setProgress(84, 'Patching...');

        const buffer = await fileToProcess.arrayBuffer();
        const dv = new DataView(buffer);
        const u8 = new Uint8Array(buffer);
        const elst = [0x65, 0x6C, 0x73, 0x74];
        let ei = -1;
        for (let i = 0; i < u8.length - 4; i++) {
            if (u8[i] === elst[0] && u8[i + 1] === elst[1] &&
                u8[i + 2] === elst[2] && u8[i + 3] === elst[3]) { ei = i; break; }
        }
        if (ei !== -1) dv.setUint32(ei + 8, config.payload, false);
        tLog('Binary patch applied', 'success');

        setPhase(3, 'INJECTING', 'Encoding data for transfer...');
        tLog('Encoding video data...', 'normal');
        setProgress(90, 'ENCODING DATA...');

        const base64Data = await bufferToDataURL(buffer);
        const fileName = selectedFile.name.replace(/\.[^/.]+$/, '') + '_maska.mp4';

        tLog('Looking for TikTok tab...', 'normal');
        setProgress(93, 'FINDING TIKTOK TAB...');

        const tikTokTabs = await chrome.tabs.query({ url: '*://*.tiktok.com/*' });
        let targetTabId = null;
        let needsWait = false;

        if (tikTokTabs.length > 0) {
            const uploadTab = tikTokTabs.find(t =>
                t.url && (
                    t.url.includes('/upload') ||
                    t.url.includes('/creator-center') ||
                    t.url.includes('/studio')
                )
            );
            targetTabId = (uploadTab || tikTokTabs[0]).id;
            tLog('Found TikTok tab — sending file...', 'normal');
        } else {
            tLog('Opening TikTok upload page...', 'normal');
            const newTab = await chrome.tabs.create({
                url: 'https://www.tiktok.com/upload',
                active: false
            });
            targetTabId = newTab.id;
            needsWait = true;
            await new Promise(resolve => {
                chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
                    if (tabId === newTab.id && info.status === 'complete') {
                        chrome.tabs.onUpdated.removeListener(listener);
                        setTimeout(resolve, 2500);
                    }
                });
            });
        }

        setProgress(96, 'UPLOADING TO TIKTOK...');
        tLog('Injecting file payload...', 'normal');

        const results = await chrome.scripting.executeScript({
            target: { tabId: targetTabId },
            args: [base64Data, fileName],
            func: injectIntoTikTok
        });

        const result = results?.[0]?.result;
        if (!result?.ok) {
            throw new Error(result?.error || 'Injection failed — make sure you are on tiktok.com/upload');
        }

        chrome.tabs.update(targetTabId, { active: true });

        setProgress(100, 'DONE!');
        tLog('VIDEO INJECTED INTO TIKTOK ✓', 'success');

        setTimeout(() => {
            hideOverlay();
            startBtn.classList.add('success-mode');
            startBtn.textContent = '✓ INJECTED TO TIKTOK';
            uploadTextEl.textContent = 'VIDEO SENT TO TIKTOK';
            uploadZone.classList.remove('processing');
            setTimeout(resetUI, 4000);
        }, 1000);

    } catch (err) {
        tLog('ERROR: ' + err.message, 'error');
        hideOverlay();
        startBtn.textContent = 'RETRY';
        startBtn.classList.add('ready');
        startBtn.disabled = false;
        uploadZone.classList.remove('processing');
        uploadZone.classList.add('has-file');
        isProcessing = false;
    }
});

function resetUI() {
    startBtn.classList.remove('success-mode', 'ready');
    startBtn.textContent = 'Post it !';
    delete startBtn.dataset.action;
    startBtn.disabled = true;
    selectedFile = null;
    isProcessing = false;
    fileInput.value = '';
    uploadZone.classList.remove('has-file', 'processing');
    uploadTextEl.textContent = 'DROP MP4 · SELECT FILE';
    ['b-res', 'b-fps', 'b-bitrate', 'b-size'].forEach(id => $(id).textContent = '—');
}
