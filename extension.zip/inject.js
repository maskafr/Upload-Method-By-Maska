(function() {

    function isUploadPage() {
        const url = window.location.href;
        return url.includes('/upload') || url.includes('/creator-center');
    }

    if (typeof window._mm_isModeActive === 'undefined') {
        window._mm_isModeActive = false;
    }

    window.activate60FPS = function() {
        window._mm_isModeActive = true;
        return { status: "ACTIVE" };
    };

    window.reset60FPS = function() {
        window._mm_isModeActive = false;
        return { status: "RESET" };
    };

    const originalJSONStringify = JSON.stringify;

    JSON.stringify = function(value, replacer, space) {
        if (!isUploadPage()) {
            return originalJSONStringify.apply(this, arguments);
        }

        if (window._mm_isModeActive && value && typeof value === 'object') {
            try {
                const deepClean = (obj) => {
                    if (!obj || typeof obj !== 'object') return;

                    const forbiddenKeys = ['draft', 'canvas_config', 'vedit_segment_info'];
                    forbiddenKeys.forEach(key => {
                        if (obj.hasOwnProperty(key)) delete obj[key];
                    });

                    if (obj.cloud_edit_is_use_video_canvas !== undefined) {
                        obj.cloud_edit_is_use_video_canvas = false;
                    }

                    if (obj.post_type === 2) {
                        obj.post_type = 3;
                    }

                    if (obj.enter_post_page_from !== undefined) {
                        obj.enter_post_page_from = 1;
                    }

                    for (let k in obj) {
                        if (obj[k] && typeof obj[k] === 'object') {
                            deepClean(obj[k]);
                        }
                    }
                };

                if (value.single_post_req_list || value.vedit_common_info || value.post_common_info) {
                    deepClean(value);
                }
            } catch (e) {}
        }

        return originalJSONStringify.apply(this, arguments);
    };

})();
